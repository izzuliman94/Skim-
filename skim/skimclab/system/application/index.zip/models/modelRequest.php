<?php
	class ModelRequest extends Model {
		function ModelRequest(){
			parent::Model();	
		}
	}	
?>