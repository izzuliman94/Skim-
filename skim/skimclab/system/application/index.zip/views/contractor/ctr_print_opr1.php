<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SKIM - OPR1</title>
</head>

<body>
<table id="table1" style="border-collapse:collapse; border-right-width:0; border-bottom-width:0" height="678" cellSpacing="0" cellPadding="0" width="803" border="1" bordercolor="#111111">
    <tbody>
    <tr>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: 1px solid #111111; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" bgColor="#c0c0c0" colSpan="10" height="15" width="791">
      <p align="left"><b><font face="Arial" size="2">&#160;1. Particulars</font></b></p>
      </td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="10" height="17" width="791">&#160;</td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" align="left" width="179" height="17">
      <p align="left"><font face="Arial" size="2">&#160;Company Name</font></p>
      </td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="9" width="612" height="17">
      <font face="Arial" size="2">: <?php echo $ctr->ctr_comp_name;?></font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" align="left" width="179" height="17">
      <font face="Arial" size="2">&#160;Company Reg. No</font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="6" width="278" height="17">
      <font face="Arial" size="2">: <?php echo $ctr->ctr_comp_regno;?></font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="166" height="17">
      </td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" height="17" width="172">
      <font></font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" align="left" width="179" height="17">
      <font face="Arial" size="2">&#160;Company Address</font></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="9" width="612" height="17">
      <font face="Arial" size="2">: <?php echo $ctr->ctr_addr1;?><?php echo " " . $ctr->ctr_addr2;?> <?php echo $ctr->ctr_addr3;?></font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" align="left" width="179" height="17">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="6" width="278" height="17">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="166" height="17">
      </td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" height="17" width="172">
      </td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" align="left" width="179" height="17">
      <font face="Arial" size="2">&#160;Telephone No</font> </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="6" width="278" height="17">
      <font face="Arial" size="2">: <?php echo $ctr->ctr_telno;?></font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="166" height="17">
      <font face="Arial" size="2">&#160;Postcode</font></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" height="17" width="172">
      <font face="Arial" size="2">:<?php echo $ctr->ctr_pcode;?></font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" align="left" width="179" height="17">
      <font face="Arial" size="2">&#160;CIDB Registration No</font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="17">
      <font face="Arial" size="2">: <?php echo $ctr->ctr_cidb_regno;?></font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="17">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="166" height="17">
      <font face="Arial" size="2">&#160;Fax No:</font></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" height="17" width="172">
      <font face="Arial" size="2">: <?php echo $ctr->ctr_fax;?></font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" align="left" width="179" height="17">
      <font face="Arial" size="2">&#160;CIDB Expiry Date</font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="17">
      <font face="Arial" size="2">: <?php echo date('d-m-Y', strtotime($ctr->ctr_cidbexp_date));?></font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="17">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="166" height="17">
      <font face="Arial" size="2">&#160;Email Address:</font></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" height="17" width="172">
      <font face="Arial" size="2">: <?php echo $ctr->ctr_email;?></font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" align="left" width="179" height="17">
      <font face="Arial" size="2">&#160;Grade</font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="17">
      <font face="Arial" size="2">: <?php echo $ctr->ctr_grade;?></font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="17">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="166" height="17">
      </td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" height="17" width="172">
      </td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" align="left" width="179" height="17">
      <font face="Arial" size="2">&#160;Specialisation</font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="17">
      <font face="Arial" size="2">: <?php echo $ctr->ctr_spec;?></font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="17">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="166" height="17">
      <font face="Arial" size="2">&#160;Category Code:</font></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" height="17" width="172">
      <font face="Arial" size="2">: <?php echo $ctr->ctr_category;?></font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" align="left" width="179" height="17">
      <font face="Arial" size="2">&#160;</font><font face="Arial" size="1">(As registered 
      with CLAB)</font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="17">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="17">
      </td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" height="17" width="334">
      <font face="Arial" size="2">&#160;</font><font face="Arial" size="1">(CE-Civil 
      Engineering, B-Building, ME - Mechanical &amp; Electrical)</font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: 1px solid; " align="left" width="179" height="18">
      <font face="Arial" size="2">&#160;</font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: 1px solid; " vAlign="top" align="left" colSpan="3" width="139" height="18">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: 1px solid; " vAlign="top" align="left" colSpan="3" width="139" height="18">
      </td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: 1px solid" vAlign="top" align="left" colSpan="3" height="18" width="334">
      </td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="10" height="17" width="791">
      </td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="6" height="17" width="344" bgcolor="#C0C0C0">
      <b><font face="Arial" size="2"><span style="BACKGROUND-COLOR: #c0c0c0">&#160;2. 
      Period of Registration Applied For: (Tick One)</span></font></b></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="113" height="17">
      </td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" height="17" width="334" bgcolor="#C0C0C0">
      <b><font face="Arial" size="2"><span style="BACKGROUND-COLOR: #c0c0c0">&#160;3. 
      Payment</span></font></b></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="10" height="17" width="791">
      </td>
    </tr>
    <tr>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="178" height="19">
      <font face="Arial" size="2">&nbsp;a. One year @ RM20</font></td>
      <td style="BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; BORDER-LEFT: 1px solid; BORDER-BOTTOM: 1px solid" vAlign="top" borderColorLight="#000000" align="left" borderColorDark="#000000" width="36" height="19">
      <p align="center"><input type="checkbox" name="chkperiodreg1" value="1" <?php if($ctr->ctr_periodreg == '1') echo "CHECKED"?> DISABLED/></p>
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" width="100" height="19">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="19">&#160;</td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; border-right:1px solid;" vAlign="top" align="left" width="165" height="19">
      <font face="Arial" size="2">&nbsp;a. Cash</font></td>
      <td style="BORDER-BOTTOM: 1px solid; border-top-color:inherit" vAlign="top" align="left" width="7" height="19">
      <p align="center"><input type="checkbox" name="paycash" value="1" <?php if($ctr->ctr_paymentype == '1') echo "CHECKED";?> DISABLED/></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-BOTTOM: medium none; border-left:1px solid;" vAlign="top" align="left" width="201" height="19">&#160;<font face="Arial" size="2"></font></td>
    </tr>
    <tr>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="178" height="20">
      <font face="Arial" size="2">&nbsp;b. Two Year @ RM40</font></td>
      <td style="BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; BORDER-LEFT: 1px solid; BORDER-BOTTOM: 1px solid" vAlign="top" borderColorLight="#000000" align="left" borderColorDark="#000000" width="36" height="20">
      <p align="center"><input type="checkbox" name="chkperiodreg2" value="1" <?php if($ctr->ctr_periodreg == '2') echo "CHECKED"?> DISABLED/></p>
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" width="100" height="20">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="20">&#160;</td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; border-right-style:none; border-right-width:medium" align="left" width="165" height="20">
      <font face="Arial" size="2">&nbsp;&nbsp;&nbsp;&nbsp; Cash Date</font></td>
      <td style="border-left:medium none; border-right:1px solid; border-top:medium none; border-bottom:medium none; " align="left" width="170" height="20" colspan="2">
      <p align="left"><font face="Arial" size="2">: <?php if($ctr->ctr_cshdate != "0000-00-00") echo date('d-m-Y', strtotime($ctr->ctr_cshdate));?></font></td>
    </tr>
    <tr>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="178" height="13">
      <font face="Arial" size="2">&nbsp;c. Three Year @ RM50</font></td>
      <td style="BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; BORDER-LEFT: 1px solid; BORDER-BOTTOM: 1px solid" vAlign="top" borderColorLight="#000000" align="left" borderColorDark="#000000" width="36" height="13">
      <p align="center"><input type="checkbox" name="chkperiodreg3" value="1" <?php if($ctr->ctr_periodreg == '3') echo "CHECKED"?> DISABLED/></p>
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" width="100" height="13">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="13">&#160;</td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; border-right-color:inherit" vAlign="top" align="left" width="166" height="13">&#160;<font face="Arial" size="2">b. 
      Cheque/Draft/MO</font></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: 1px solid; BORDER-LEFT: 1px solid; BORDER-BOTTOM: 1px solid; " vAlign="top" align="left" height="13" width="31">
      <p align="center">&nbsp;<input type="checkbox" name="paycheque" value="1" <?php if($ctr->ctr_paymentype == '2') echo "CHECKED";?> DISABLED/></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-BOTTOM: medium none; border-left-color:inherit" vAlign="top" align="left" height="13" width="141"></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="7" rowSpan="3" width="457" height="66">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" align="left" width="166" height="23">
      <font face="Arial" size="2">&#160;&nbsp;&nbsp;&nbsp; Cheque/Draft/MO No</font></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" align="left" colSpan="2" height="23" width="172"><font face="Arial" size="2">:&nbsp;<?php echo $ctr->ctr_chqno;?></font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" align="left" width="166" height="21">
      <font face="Arial" size="2">&#160;&nbsp;&nbsp;&nbsp; Cheque/Draft/MO Date</font></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" align="left" colSpan="2" height="21" width="172"><font face="Arial" size="2">:&nbsp;<?php if($ctr->ctr_chqdate != "0000-00-00") echo date('d-m-Y', strtotime($ctr->ctr_chqdate));?></font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none" vAlign="top" align="left" width="166" height="18">
      </td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none" vAlign="top" align="left" colSpan="2" height="18" width="172">
      </td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" bgColor="#c0c0c0" colSpan="2" height="18" width="217">
      <b><font face="Arial" size="2">&#160;4. Attachments</font></b></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="18" width="21">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: 1px solid; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="4" height="18" width="226">
      <b><font face="Arial" size="2">&#160;For Office Use</font></b></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: 1px solid; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="18" width="166">
      <b><font face="Arial" size="2">&#160;CLAB No</font></b></td>
      <td style="BORDER-TOP: 1px solid; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; border-right-color:#111111; border-right:1px solid;" vAlign="top" align="left" width="171" colSpan="2" height="18">
      <font face="Arial" size="2">: <b><?php echo $ctr->ctr_clab_no;?></b></font></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="18" width="179">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none" vAlign="top" align="left" height="18" width="38">
      </td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="18" width="20">
      </td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="7" height="18" width="559">
      </td>
    </tr>
    <tr>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="178">
      <font face="Arial" size="2">&nbsp;a. Form 24</font></td>
      <td style="BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; BORDER-LEFT: 1px solid; BORDER-BOTTOM: 1px solid" vAlign="top" align="left" height="19" width="36">
      <p align="center"><input type="checkbox" name="form24" value="1" <?php if($ctr->ctr_attach_form24 == '1') echo "CHECKED";?> DISABLED/></td>
      <td style="BORDER-TOP: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="19">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="87">
      <font face="Arial" size="2">&nbsp;Processed by</font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" height="19" width="139">: <?php echo $ctr->ctr_procsby;?></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="166">
      <font face="Arial" size="2">&nbsp;Date Processed</font></td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; border-right-color:#111111; border-right:1px solid" vAlign="top" align="left" colSpan="2" height="19" width="171">: <?php echo date('d-m-Y', strtotime($ctr->ctr_procdate));?></td>
    </tr>
    <tr>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="178">
      <font face="Arial" size="2">&nbsp;b. Form 49</font></td>
      <td style="BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; BORDER-LEFT: 1px solid; BORDER-BOTTOM: 1px solid" vAlign="top" align="left" height="19" width="36">
      <p align="center"><input type="checkbox" name="form49" value="1" <?php if($ctr->ctr_attach_form49 == '1') echo "CHECKED";?> DISABLED/></td>
      <td style="BORDER-TOP: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="19">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="87">
      <font face="Arial" size="2">&nbsp;Verified by</font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" height="19" width="139">: <?php echo $ctr->ctr_verifiedby;?></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="166">
      <font face="Arial" size="2">&nbsp;Date Verified</font></td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; border-right-color:#111111; border-right:1px solid" vAlign="top" align="left" colSpan="2" height="19" width="171">: <?php if($ctr->ctr_verifieddate != '0000-00-00') echo date('d-m-Y', strtotime($ctr->ctr_verifieddate));?></td>
    </tr>
    <tr>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="178" height="21">
      <font face="Arial" size="2">&#160;c. Copy of CIDB Certificate</font></td>
      <td style="BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; BORDER-LEFT: 1px solid; BORDER-BOTTOM: 1px solid" vAlign="top" align="left" width="36" height="21">
      <p align="center"><input type="checkbox" name="cidb_certcopy" value="1" <?php if($ctr->ctr_attach_copycidb == '1') echo "CHECKED";?> DISABLED/></td>
      <td style="BORDER-TOP: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="19" height="21">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="87" height="21">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="21">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="166" height="21">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="7" height="21">&#160;</td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="201" height="21">&#160;</td>
    </tr>
    <tr>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="178" height="19">
      <font face="Arial" size="2">&nbsp;d. Others</font></td>
      <td style="BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; BORDER-LEFT: 1px solid; BORDER-BOTTOM: 1px solid" vAlign="top" align="left" width="36" height="19">
      <p align="center"><input type="checkbox" name="others" value="1" <?php if($ctr->ctr_attach_others == '1') echo "CHECKED";?> DISABLED/></td>
      <td style="BORDER-TOP: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="19" height="19">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="4" width="226" height="19">
      <b><font face="Arial" size="2">&#160;Application Status &amp; Approval</font></b></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="166" height="19">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="7" height="19">&#160;</td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; border-right-color:#111111; border-right:1px solid;" vAlign="top" align="left" width="201" height="19">&#160;</td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="179" height="18">
      &nbsp;<font face="Arial" size="2">Specifiy :</font></td>
      <td style="BORDER-RIGHT: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="38" height="18">
      </td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="20" height="18">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="87" height="18">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="3" width="139" height="18">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="166" height="18">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="7" height="18">
      </td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; border-right-color:#111111; border-right:1px solid;" vAlign="top" align="left" width="201" height="18">
      </td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="20" width="179">&nbsp;<?php echo $ctr->ctr_attach_specify;?></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="20" width="38">&#160;</td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="20" width="20">&#160;</td>
      <td style="BORDER-RIGHT: 1px solid; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="20" width="86">
      &nbsp;Approved</td>
      <td style="BORDER-RIGHT: 1px solid" vAlign="top" align="left" height="20" width="23">
      <p align="center"><input type="checkbox" name="isapproved" <?php if($ctr->ctr_approve == '1') echo "CHECKED";?> DISABLED/> </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" height="20" width="113">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="20" width="166">
      <font face="Arial" size="2">&nbsp;Approved / Rejected by</font></td>
      <td style="BORDER-RIGHT: 1px solid #111111; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" colSpan="2" height="20" width="171">: <?php echo $ctr->ctr_app_name;?></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="179">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="38">&#160;</td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="20">&#160;</td>
      <td style="BORDER-RIGHT: 1px solid; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="86">
      &nbsp;Rejected</td>
      <td style="BORDER-RIGHT: 1px solid" vAlign="top" align="left" width="23" height="19">
      <p align="center"><input type="checkbox" name="isrejected" <?php if($ctr->ctr_reject == '1') echo "CHECKED";?> DISABLED/></td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" width="113" colSpan="2" height="19">&#160;</td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" vAlign="top" align="left" height="19" width="166">
      <font face="Arial" size="2">&nbsp;Date Approve / Reject</font></td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none; border-right-color:#111111; border-right:1px solid;" vAlign="top" align="left" colSpan="2" height="19" width="171">: <?php if($ctr->ctr_approve == '1') echo date('d-m-Y', strtotime($ctr->ctr_app_date)); else if($ctr->ctr_reject == '1') echo date('d-m-Y', strtotime($ctr->ctr_rej_date)); else {}?></td>
    </tr>
    <tr>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: 1px solid;" vAlign="top" align="left" height="17" width="179">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: 1px solid;" vAlign="top" align="left" height="17" width="38">
      </td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: 1px solid;" vAlign="top" align="left" height="17" width="20">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: 1px solid; BORDER-BOTTOM: 1px solid;" vAlign="top" align="left" height="17" width="87">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: 1px solid;" vAlign="top" align="left" colSpan="3" height="17" width="139">
      </td>
      <td style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: 1px solid;" vAlign="top" align="left" height="17" width="166">
      <font face="Arial" size="2">&nbsp;Reason for Rejection</font></td>
      <td style="BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: 1px solid;; border-right-color:#111111; border-right:1px solid;" vAlign="top" align="left" colSpan="2" height="17" width="171">:  <?php echo $ctr->ctr_reject_reason;?></td>
    </tr>
  </tbody>
  </table>
</body>
</html>
