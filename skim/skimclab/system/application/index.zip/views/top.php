<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SKIM</title>
<link href="<?php echo base_url();?>css/sippsstyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">

.style1 {font-size: 20px;
		 font-family: Arial, Helvetica, sans-serif;
		}
body {
	background-image: url(<?php echo base_url()?>images/banner.jpg);
	background-repeat: repeat-x;
}
.style2 {font-size: xx-large}
.style3 {font-size: 12px;
		 font-family: Arial, Helvetica, sans-serif;
		}
</style>
</head>

<body bottommargin="0" rightmargin="0" leftmargin="0" topmargin="0">
<table width="100%" height = "111" border="0" cellspacing="0" cellpadding="0" STYLE="background-image: url('<?php echo base_url()?>images/banner.jpg'); background-repeat: repeat-x;">
    <td width="20%" STYLE="background-image: url('<?php echo base_url()?>images/banner.jpg'); background-repeat: repeat-x;">&nbsp; &nbsp; &nbsp;<img src="<?php echo base_url();?>/images/image002.gif" height="106px" width="177px"/></td>
    <td width="50%" class="style1" valign="center" align="left" STYLE="background-image: url('<?php echo base_url()?>images/banner.jpg'); background-repeat: repeat-x;">SISTEM KENDALIAN PEKERJA IMIGRAN (SKIM)</td>
    <td width="30%" valign="top" align="right" class="style3" STYLE="background-image: url('<?php echo base_url()?>images/banner.jpg'); background-repeat: repeat-x;">Login as: <?php echo $this->session->userdata('username');?></td>
  </tr>
</table>
</body>






</html>
