<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
<title>SPIM-Handover Letter</title>
<style type="text/css">
th {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000000;
	font-weight: bold;
}

td {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #333333;
}
</style>
</head>
<body>
<table style="text-align: left; width: 616px;" align="center" border="0" cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td colspan="4" rowspan="1">&nbsp;      </td>
    </tr>
    <tr>
      <td width="47%">&nbsp;</td>
      <td width="17%">&nbsp;</td>
      <td width="18%">&nbsp;</td>
      <td colspan="1" rowspan="9" valign="top" width="18%"><img src="<?php echo base_url();?>images/logoLetter.jpg">
      	<br /><br />
      <span style="font-size: 6pt; font-family: &quot;Arial&quot;; color: navy;">
		CONSTRUCTION LABOUR EXCHANGE CENTRE BERHAD (634396-W) <br>
		Lot 1-3, Level 6, Block C (South), Pusat Bandar Damansara, 50490 Kuala Lumpur. <br>
		Tel: 03-2095 9599 <br>
		Fax: 03-2095 9566 <br>
		E-mail: info@clab.com.my <br>
		Website: www.clab.com.my <br>
      </span></td>
    </tr>
    <tr>
      <td colspan="2" rowspan="1">
        <br /></br /><br />
      	Rujukan Kami: CLAB/CSP/GEN/<?php if($woRow->wo_num == '') echo $woRow->wo_id; else echo $woRow->wo_num;?></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" rowspan="1"><br />
        Tarikh: <?php echo date('j F Y');?></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="3">&nbsp;</td>
    </tr>
    
    <tr>
      <td><br /><br />
        <b>Jabatan Imigresen Malaysia</b></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>Ibu Pejabat Jabatan Imigresen Malaysia<br />
		  Kementerian Hal Ehwal Dalam Negeri</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>Tingkat 1-7, (Podium) Blok 2G4<br />
      Precint 2, Pusat Pentadbiran Kerajaan Persekutuan</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><span style="text-align: right;">62550 Putrajaya</span></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
     
     <tr>
      <td colspan="3">&nbsp;</td>
    </tr>
    <tr>
       <td colspan="4">U/p  : <em><strong>Pengarah Bahagian Pekerja Asing</strong></em><strong></strong></td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4">Tuan,</td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
	<tr>
      <td colspan="4"><strong><u>PERMOHONAN MEMO PERIKSA KELUAR</u></strong></td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4"><p>Dengan segala hormatnya, kami merujuk perkara diatas.</p>      </td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
  <td colspan="4"><p>Pihak kami ingin memohon kerjasama pihak tuan untuk mendapatkan Memo Periksa Keluar bagi  pekerja berkenaan. Bersama ini kami kepilkan salinan tiket dan passport pekerja sebagai rujukan pihak tuan.</p></td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4"><p>Kerjasama daripada pihak tuan amatlah kami hargai.</p>      </td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4"><p>&nbsp;</p></td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4"><p>      Sekian,  terima kasih.</p></td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4"><p>Yang  benar,<br />
      CONSTRUCTION LABOUR EXCHANGE CENTRE BERHAD      </p>      </td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4"><p><strong>ADB RAFIK ABD RAJIS</strong><br>
            <strong>Ketua Jabatan Perkhidmatan Korporat</strong> </p></td>
    </tr>
       <tr>
      <td colspan="4">---------------------------------------------------------------------------------------------------------------------------------------------------------</td>
    </tr>
    <tr bordercolor="#000000">
      <td colspan="4"><p>s.k. <b><?php echo $woRow->ctr_comp_name;?></b></p></td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4"><em>Lampiran</em></td>
    </tr>
    <tr>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4">
        <span style="font-size: 7pt; font-family: &quot;Arial&quot;;">
      	<i>/<?php echo $this->session->userdata('username');?></i>      	</span></td>
    </tr>
  </tbody>
</table>
</body>
</html>
