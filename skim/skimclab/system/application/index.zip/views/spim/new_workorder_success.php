<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SKIM</title>
<link href="../css/sippsstyle.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="../js/switchcontent.js" >

/***********************************************
* Switch Content script- � Dynamic Drive (www.dynamicdrive.com)
* This notice must stay intact for legal use. Last updated April 05th, 2007.
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>

<script type="text/javascript" src="../js/crumb.js" >

/**** breadcrumb script  - for testing purposes *********/

</script>


</head>

<body>

<h4><a href="dashboard.php">Immigration</a> <img src="../images/right_arrow.gif" width="13" height="14" /> New Work Order </h4>

<p>
  <!-- <script language="JavaScript"> -->
  <!-- 
breadcrumbs(); 
 -->
  <!-- </script> -->
  
  <!-- <php include("../backlinks.php"); ?> -->
  
  <!-- <script type="text/javascript" src="../js/MPBackLinks.js"></script> --><br />
  <a href="../main.php"></a></p>
<table width="100%" border="0">
  <tr>
    <td colspan="3"><div align="center"><span class="big">Workorder Saved Successful</span></div></td>
  </tr>
  
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td width="40%"><div align="center"><a href="new_workorder_pt1.php">Add New Workorder</a></div></td>
    <td width="20%"><div align="center"></div></td>
    <td width="40%"><div align="center"><a href="dashboard.php">Return to Immigration Dashboard </a><a href="../main.php"></a></div></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
