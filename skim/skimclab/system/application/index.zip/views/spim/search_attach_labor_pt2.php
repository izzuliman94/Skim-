<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SKIM</title>
<link href="../css/sippsstyle.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="../js/switchcontent.js" >

/***********************************************
* Switch Content script- � Dynamic Drive (www.dynamicdrive.com)
* This notice must stay intact for legal use. Last updated April 05th, 2007.
* Visit http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>
</head>

<body>



<h4><a href="dashboard.php">Immigration</a> <img src="../images/right_arrow.gif" width="13" height="14" /> <a href="search_attach_labor_pt1.php">Search</a> Labor</h4>

<div><a href="javascript:switchsection.sweepToggle('contract')">Contract All</a> | <a href="javascript:switchsection.sweepToggle('expand')">Expand All</a></div>

<h3 id="switchsection1-title" class="handcursor">Immigration - Search Labour <img src="../images/down_arrow_org.gif" width="13" height="14" /></h3>
<div id="switchsection1" class="switchgroup1"> 


  <form action="../contractor/approval_pt2.php" method="get" name="TypicalForm" id="TypicalForm">
    <table width="100%" border="0">
	
      <tr>
        <th width="25%"><div align="left">Search By </div></th>
        <th width="5%">&nbsp;</th>
        <th width="70%">&nbsp;</th>
      </tr>
      <tr>
        <td><select name="select">
          <option value="1">Name</option>
          <option value="2">Passport</option>
          </select>
        </td>
        <td><div align="center">:</div></td>
        <td><input type="text" name="txtTypicalForm" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td><input type="submit" name="TypicalButton" value="Search" /></td>
      </tr>
    </table>
  </form>
</div>
<p>
      <script type="text/javascript">
//   MAIN FUNCTION: new switchcontent("class name", "[optional_element_type_to_scan_for]") REQUIRED
//1) Instance.setStatus(openHTML, closedHTML)- Sets optional HTML to prefix the headers to indicate open/closed states
//2) Instance.setColor(openheaderColor, closedheaderColor)- Sets optional color of header when it's open/closed
//3) Instance.setPersist(true/false)- Enables or disabled session only persistence (recall contents' expand/contract states)
//4) Instance.collapsePrevious(true/false)- Sets whether previous content should be contracted when current one is expanded
//5) Instance.defaultExpanded(indices)- Sets contents that should be expanded by default (ie: 0, 1). Persistence feature overrides this setting!
//6) Instance.init() REQUIRED

var switchsection=new switchcontent("switchgroup1", "div") //Limit scanning of switch contents to just "div" elements
//bobexample.setStatus('<img src="http://img242.imageshack.us/img242/5553/opencq8.png" /> ', '<img src="http://img167.imageshack.us/img167/7718/closedy2.png" /> ')
switchsection.setColor('darkred', 'black')
switchsection.setPersist(true)
switchsection.collapsePrevious(true) //Only one content open at any given time
switchsection.init()
    </script>
</p>

<table width="100%" border="0">
  <tr>
    <th width = "5%">No</th>
    <th>Name</th>
    <th>Passport No </th>
    <th>Select</th>
  </tr>
  <tr>
    <td>1</td>
    <td>AAAAaaaa</td>
    <td>Passport # 12345 </td>
    <td><input type="checkbox" name="checkbox" value="checkbox" /></td>
  </tr>
  <tr>
    <td>2</td>
    <td>BBBBbbbbb</td>
    <td>Passport # 12345 </td>
    <td><input type="checkbox" name="checkbox2" value="checkbox" /></td>
  </tr>
  <tr>
    <td>3</td>
    <td>CCCCccccc</td>
    <td>Passport # 12345 </td>
    <td><input type="checkbox" name="checkbox3" value="checkbox" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><a href="new_workorder_pt2.php">Attach Selected </a></td>
  </tr>
</table>
</body>
</html>
