<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SKIM</title>
<link href="<?php echo base_url();?>/css/sippsstyle.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h2>Admin Dashboard</h2>
<h3 id="admindashbrd1-title" class="handcursor">List of SKIM users<img src="<?php echo base_url() ?>images/down_arrow_org.gif" width="13" height="14" /></h3>
<table width="70%" border="0">
	<tr>
		<th colspan="2">Statistics of Users per Department</th>
	</tr>
	<tr>
		<th width="60%">Department</th>
		<th width="40%">Statistics</th>
	</tr>
	<tr>
		<td>OPERATION</td>
		<td align="CENTER"><a href="<?php echo site_url();?>/contAdmin/viewEmpListByDpt/1"><?php echo $totalOPR;?></a></td>
	</tr>
	<tr>
		<td>FINANCE</td>
		<td align="CENTER"><a href="<?php echo site_url();?>/contAdmin/viewEmpListByDpt/2"><?php echo $totalFIN;?></a></td>
	</tr>
	<tr>
		<td>HUMAN RESOURCES</td>
		<td align="CENTER"><a href="<?php echo site_url();?>/contAdmin/viewEmpListByDpt/3"><?php echo $totalHR;?></a></td>
	</tr>
	<tr>
		<td>ADMIN</td>
		<td align="CENTER"><a href="<?php echo site_url();?>/contAdmin/viewEmpListByDpt/4"><?php echo $totalADMIN;?></a></td>
	</tr>
	<tr>
		<td>IT</td>
		<td align="CENTER"><a href="<?php echo site_url();?>/contAdmin/viewEmpListByDpt/5"><?php echo $totalIT;?></a></td>
	</tr>
</table>
</body>
</html>
